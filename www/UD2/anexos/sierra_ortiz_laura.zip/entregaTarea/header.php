    <!--CABECERA DE LA PÁGINA-->
    
    <header class="bg-primary text-white text-center py-3">
        <h1><?php echo "UD2 - Laura Sierra Ortiz" ?></h1>
        <h2><?php echo "Tarea  2 - Desarrollo de una Aplicación Básica en PHP" ?></h2>
    </header>





