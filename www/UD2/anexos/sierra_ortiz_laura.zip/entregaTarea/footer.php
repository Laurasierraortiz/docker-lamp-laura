<!--PIE DE LA PÁGINA-->

<footer class="bg-dark text-white text-center py-3">
    <?php
        echo "<span>&copy</span> Laura Sierra Ortiz. DIWCS. San Clemente.";
    ?>
</footer>