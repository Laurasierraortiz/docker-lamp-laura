<!--MENÚ LATERAL-->

<nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
    <div class="position-sticky">
        <ul class="nav flex-column">

            <li class="nav-item">
                <a class="nav-link" href="index.php">Home</a> <!--enlace a index.php-->
            </li>

            <li class="nav-item">
                <a class="nav-link" href="listaTareas.php">Mis tareas</a> <!--enlace a ilistaTareas.php-->
            </li>

            <li class="nav-item">
                <a class="nav-link" href="nuevaForm.php">Nueva tarea</a> <!--enlace a nuevaForm.php-->
            </li>
        </ul>
    </div>
</nav>