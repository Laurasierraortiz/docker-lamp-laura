<!--PIE DE PÁGINA-->
<footer class="bg-dark text-white text-center py-2">
    <p>© 2024 Laura Sierra Ortiz - Todos los derechos reservados.</p>
</footer>