<!--MENÚ-->
<nav class="col-md-3 col-lg-2 d-md-block bg-light sidebar">
    <div class="position-sticky">
        <ul class="nav flex-column">
            <li class="nav-item">
                <a class="nav-link" href="/UD3/entregaTarea/index.php">Home</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/UD3/entregaTarea/init.php">Inicializar</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/UD3/entregaTarea/usuarios/usuarios.php">Lista de usuarios</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/UD3/entregaTarea/usuarios/nuevoUsuarioForm.php">Nuevo usuario</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/UD3/entregaTarea/tareas/tareas.php">Lista de tareas</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/UD3/entregaTarea/tareas/nuevaForm.php">Nueva tarea</a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="/UD3/entregaTarea/tareas/buscaTareas.php">Buscador de tareas</a>
            </li>
        </ul>
    </div>
</nav>